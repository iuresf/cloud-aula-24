# Aula 25 — Data Lake com Glue Workflow, múltiplas fontes e rastreabilidade

Caso fictício reproduzível: uma loja vende por **web, app e marketplace**. Os relatórios misturavam pedidos criados, pagamentos efetivamente aprovados e visitas. Depois de um estorno, o painel mostrou receita incorreta. Este projeto responde às perguntas com duas cargas em momentos diferentes e guarda trilha de origem.

## Perguntas de negócio e grau

| Pergunta | Grau adequado | Fonte de resposta |
|---|---|---|
| Qual receita líquida por canal, UF e categoria? | dia × canal × UF × categoria | Gold `indicadores_vendas` e estrela em `05_estrela.sql` |
| Quantas sessões converteram por canal? | dia × canal, sessões distintas | Gold `indicadores_funil` |
| Uma aprovação tardia pode alterar receita histórica? | item do pedido e status do pagamento mais recente | Gold `fato_vendas` |
| Quais arquivos produziram a receita do pedido P1002? | pedido_id + item_id e eventos | `fato_vendas` → Silver → manifestos |
| O que acontece ao repetir o evento EV04? | evento_id | deduplicação Silver |

**Importante:** a taxa de conversão não pode ser agregada no grau categoria/UF, porque uma sessão não pertence necessariamente a uma categoria e um JOIN por item multiplica sessões. Mantenha indicadores de funil separados.

## Arquitetura executada

```text
Pedidos CSV --┐
Produtos CSV -┤
Pagamentos JSONL ├--> S3 Bronze (imutável, versionado)
Eventos JSONL --┘             │
                        manifesto ingestão
                              │
runner.py --> Glue Workflow [on-demand]
                   ├─ Trigger inicial → Glue Job SILVER
                   │                     ├── S3 Silver: 4 tabelas Parquet
                   │                     └── manifesto Silver
                   └─ Trigger condicionado SUCCEEDED → Glue Job GOLD
                                                  ├── S3 Gold: fato + 4 dimensões + 2 indicadores
                                                  └── manifesto Gold
Glue Data Catalog (DDL Terraform: esquemas + locations) → Amazon Athena
```

Glue Workflow coordena **Jobs e dependência**, não copia automaticamente o dado, não implementa dedupe e não substitui a fila da arquitetura anterior. O laboratório faz upload em lotes por CLI no lugar de provisionar API Gateway/Cognito/SQS para não exigir serviços ou permissões adicionais do Learner Lab. A arquitetura de produção da aula pode manter API → SQS → Lambda → Bronze e disparar este mesmo Workflow após o fechamento seguro de um lote.

## Dados

- `dados/inicial/`: 4 pedidos; 6 produtos; 4 eventos de pagamento; 7 sessões (quatro arquivos; pedidos/produtos CSV e pagamentos/eventos JSONL).
- `dados/delta/`: 2 pedidos novos; pagamento P1002 passa de aprovado a **estornado**; P1003 de pendente a **aprovado**; pagamentos P1005/P1006; 3 sessões novas e cópia idêntica de EV04 (três arquivos).
- A Silver atualiza o **snapshot**, seleciona último pagamento por `atualizado_em`, valida chaves e faz dedupe de eventos por `evento_id`.
- A Gold calcula receita apenas para status **aprovado**, mantém o fato no grau pedido-item, materializa uma **estrela** com `dim_produto`, `dim_tempo`, `dim_canal` e `dim_uf`, e separa o funil para não multiplicar visitas.

## Resultados esperados

| Indicador | Carga inicial | Após delta |
|---|---:|---:|
| Pedidos únicos | 4 | 6 |
| Pedidos pagos | 3 | 5 |
| Sessões únicas | 7 | 10 |
| Receita líquida | R$ 480,00 | R$ 610,00 |
| P1002 | R$ 120,00 | R$ 0,00 (estornado) |
| P1003 | R$ 0,00 | R$ 100,00 (aprovado tardiamente) |
| Evento EV04 no Silver | 1 | 1 (dedupe) |

Após delta: web R$ 320 (3 conversões / 4 sessões = 75%); app R$ 90 (1/4 = 25%); marketplace R$ 200 (1/2 = 50%). Uma consulta por UF/categoria produz SP/acessorios R$ 220, PI/casa R$ 100, SP/eletronicos R$ 200, CE/casa R$ 90 e PI/bolsas R$ 0.

## Pré-requisitos e execução no AWS Academy

> **Testado localmente quanto a sintaxe Python e dados; não executado em conta AWS Academy real.** Disponibilidade do Glue Workflows, Glue ETL, Athena, S3 e permissões da role variam por Learner Lab. Verifique antes de `apply`; se bloqueado, use os diagramas, SQL e simulador local como atividade. Não contorne políticas do laboratório.

1. Abra um Learner Lab ativo e obtenha credenciais temporárias pelo mecanismo oficial. Instale Python 3.10+, boto3, Terraform 1.5+ e AWS CLI no seu ambiente. `aws sts get-caller-identity` deve retornar a conta correta.
2. Execute `python gerar_dados.py` caso queira regerar os arquivos.
3. `cd 02_data_lake`; copie `terraform.tfvars.example` para `terraform.tfvars`; substitua `glue_role_arn` com o **ARN real de uma role preexistente** que permita Jobs Glue acessarem S3 e CloudWatch.
4. `terraform init && terraform validate && terraform plan`; revise nomes, custos e permissões; `terraform apply`.
5. Volte à raiz do projeto e rode `python runner.py initial`. O runner faz upload, grava manifesto, chama **start_workflow_run** e aguarda Silver + Gold e os dois manifestos, então verifica a consulta Athena.
6. `python runner.py delta`; o mesmo Workflow refaz snapshots e corrige receita histórica.
7. `python runner.py trace --pedido P1002`; rode separadamente as consultas em `02_data_lake/sql/` no Athena, incluindo `05_estrela.sql` (JOIN da fato com quatro dimensões).
8. Inspecione `s3://<bucket-results>/manifestos/{bronze,silver,gold}/`. Confira `source_key` da linha Silver/Gold no manifesto de ingestão e localize `version_id` e `sha256` do arquivo Bronze.
9. Ao terminar, **revise** `terraform plan -destroy` e, se corresponde apenas aos recursos deste laboratório, `terraform destroy`. Os buckets são configurados com `force_destroy`: isso apaga dados e manifestos do projeto.

## O que não implementar ou prometer nesta prática

- **Não há API Gateway, Cognito, SQS ou EventBridge provisionados neste ZIP**; são componentes de arquitetura futura. A ingestão é `runner.py` → S3, de propósito para compatibilidade do laboratório.
- **Não é CDC, streaming ou append transacional:** Spark escreve Parquet com `overwrite` integral nas pastas Silver e Gold. Não ler durante overwrite e não executar cargas em paralelo. Para produção, adotar Iceberg com MERGE/ACID/snapshots.
- **Histórico Bronze** preserva versões por lote. **Silver e Gold** representam o snapshot atual; seus manifestos históricos **não** congelam os Parquets antigos. O catálogo aponta para **prefixos**, não para cada arquivo. Para consultas time travel em produção, uma tabela Iceberg é mais adequada.
- **Rastreabilidade**: coluna `source_key` identifica a origem por linha; `source_record_id` identifica a linha lógica; `version_id` e `sha256` do objeto Bronze são associados no manifesto. O `workflow_run_id` conecta manifestos do processamento. Isto não substitui um sistema completo de lineage de coluna.
- **Custos**: dois Jobs Spark (2 G.1X cada), Athena e S3 consomem créditos. Execute apenas as duas cargas; destrua recursos depois da validação.

Consulte `VALIDACAO.md` e `02_data_lake/README.md` antes da aula.
