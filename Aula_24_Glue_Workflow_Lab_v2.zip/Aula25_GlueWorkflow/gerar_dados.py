"""Gera dados ficticios reproduziveis de quatro fontes e dois lotes."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).parent / "dados"


def csv_file(stage, dataset, rows):
    dest = ROOT / stage / dataset / f"lote_{'001' if stage == 'inicial' else '002'}.csv"
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys(), delimiter=";")
        writer.writeheader()
        writer.writerows(rows)


def jsonl(stage, dataset, rows):
    dest = ROOT / stage / dataset / f"lote_{'001' if stage == 'inicial' else '002'}.jsonl"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


orders = [
    ("P1001", "I1", "2026-11-10", "SKU01", 2, "80.00", "web", "SP", "2026-11-10T09:00:00"),
    ("P1002", "I1", "2026-11-10", "SKU02", 1, "120.00", "app", "PI", "2026-11-10T10:00:00"),
    ("P1003", "I1", "2026-11-10", "SKU03", 2, "50.00", "web", "PI", "2026-11-10T11:00:00"),
    ("P1004", "I1", "2026-11-10", "SKU04", 1, "200.00", "marketplace", "SP", "2026-11-10T12:00:00"),
    ("P1005", "I1", "2026-11-11", "SKU05", 1, "90.00", "app", "CE", "2026-11-11T08:00:00"),
    ("P1006", "I1", "2026-11-11", "SKU06", 1, "60.00", "web", "SP", "2026-11-11T09:00:00"),
]
orders = [dict(zip(["pedido_id", "item_id", "data_pedido", "produto_id", "quantidade", "preco_unitario", "canal", "uf", "atualizado_em"], row)) for row in orders]

products = [
    ("SKU01", "Suporte de notebook", "acessorios"),
    ("SKU02", "Mochila", "bolsas"),
    ("SKU03", "Garrafa termica", "casa"),
    ("SKU04", "Fone Bluetooth", "eletronicos"),
    ("SKU05", "Luminaria LED", "casa"),
    ("SKU06", "Cabo USB-C", "acessorios"),
]


def pay(evento_id, pedido, resultado, when):
    return dict(evento_id=evento_id, pedido_id=pedido, resultado=resultado, atualizado_em=when)


pay_initial = [
    pay("PG01", "P1001", "aprovado", "2026-11-10T09:05:00"),
    pay("PG02", "P1002", "aprovado", "2026-11-10T10:05:00"),
    pay("PG03", "P1003", "pendente", "2026-11-10T11:05:00"),
    pay("PG04", "P1004", "aprovado", "2026-11-10T12:05:00"),
]
pay_delta = [
    pay("PG05", "P1002", "estornado", "2026-11-12T14:00:00"),
    pay("PG06", "P1003", "aprovado", "2026-11-12T14:10:00"),
    pay("PG07", "P1005", "aprovado", "2026-11-11T08:05:00"),
    pay("PG08", "P1006", "aprovado", "2026-11-11T09:05:00"),
]


def visit(eid, session, date, channel, event="visita", order=None):
    return dict(evento_id=eid, sessao=session, data=date, canal=channel, evento=event, pedido_id=order)


events_initial = [
    visit("EV01", "S01", "2026-11-10", "web", "checkout", "P1001"),
    visit("EV02", "S02", "2026-11-10", "app", "checkout", "P1002"),
    visit("EV03", "S03", "2026-11-10", "web", "checkout", "P1003"),
    visit("EV04", "S04", "2026-11-10", "marketplace", "checkout", "P1004"),
    visit("EV05", "S05", "2026-11-10", "web"),
    visit("EV06", "S06", "2026-11-10", "app"),
    visit("EV07", "S07", "2026-11-10", "marketplace"),
]
events_delta = [
    visit("EV04", "S04", "2026-11-10", "marketplace", "checkout", "P1004"),  # duplicata identica
    visit("EV08", "S08", "2026-11-11", "app", "checkout", "P1005"),
    visit("EV09", "S09", "2026-11-11", "web", "checkout", "P1006"),
    visit("EV10", "S10", "2026-11-11", "app"),
]

csv_file("inicial", "pedidos", orders[:4])
csv_file("delta", "pedidos", orders[4:])
csv_file("inicial", "produtos", [dict(zip(["produto_id", "nome", "categoria"], row)) for row in products])
jsonl("inicial", "pagamentos", pay_initial)
jsonl("delta", "pagamentos", pay_delta)
jsonl("inicial", "eventos", events_initial)
jsonl("delta", "eventos", events_delta)
print("Dados gerados: Bronze inicial (4 fontes) + delta (3 fontes).")
