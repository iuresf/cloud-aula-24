terraform {
  required_version = ">= 1.5, < 2.0"
  required_providers { aws = { source = "hashicorp/aws", version = "~> 6.0" } }
}
provider "aws" { region = var.region }
variable "region" {
  type = string
  default = "us-east-1"
}
variable "project" {
  type = string
  default = "a25-workflow"
}
variable "glue_role_arn" {
  type = string
  description = "ARN de role Glue preexistente e autorizada; verificar permissao no AWS Academy."
  validation {
    condition = can(regex("^arn:aws:iam::[0-9]{12}:role/", var.glue_role_arn))
    error_message = "Informe um ARN valido de role existente."
  }
}
data "aws_caller_identity" "current" {}
locals {
  db = replace(var.project, "-", "_")
  schemas = {
    pedidos = { zone = "silver", cols = { pedido_id = "string", item_id = "string", data = "date", produto_id = "string", quantidade = "int", preco_unitario = "decimal(12,2)", canal = "string", uf = "string", source_key = "string", source_record_id = "string", batch_id = "string" } }
    produtos = { zone = "silver", cols = { produto_id = "string", nome = "string", categoria = "string", source_key = "string", source_record_id = "string", batch_id = "string" } }
    pagamentos = { zone = "silver", cols = { evento_id = "string", pedido_id = "string", resultado = "string", atualizado_em = "timestamp", source_key = "string", source_record_id = "string", batch_id = "string" } }
    eventos = { zone = "silver", cols = { evento_id = "string", sessao = "string", data = "date", canal = "string", evento = "string", pedido_id = "string", source_key = "string", source_record_id = "string", batch_id = "string" } }
    fato_vendas = { zone = "gold", cols = { pedido_id = "string", item_id = "string", data = "date", produto_id = "string", canal = "string", uf = "string", quantidade = "int", valor_bruto = "decimal(14,2)", status_pagamento = "string", receita_liquida = "decimal(14,2)", pedido_source_key = "string", pagamento_source_key = "string", produto_source_key = "string", batch_id = "string" } }
    dim_produto = { zone = "gold", cols = { produto_id = "string", nome = "string", categoria = "string" } }
    dim_tempo = { zone = "gold", cols = { data = "date", ano = "int", mes = "int" } }
    dim_canal = { zone = "gold", cols = { canal = "string" } }
    dim_uf = { zone = "gold", cols = { uf = "string" } }
    indicadores_vendas = { zone = "gold", cols = { data = "date", canal = "string", uf = "string", categoria = "string", pedidos = "bigint", pagos = "bigint", receita_liquida = "decimal(14,2)" } }
    indicadores_funil = { zone = "gold", cols = { data = "date", canal = "string", sessoes = "bigint", sessoes_convertidas = "bigint", conversao = "double" } }
  }
}
resource "aws_s3_bucket" "zones" {
  for_each = toset(["bronze", "silver", "gold", "results"])
  bucket = "${var.project}-${each.key}-${data.aws_caller_identity.current.account_id}-${var.region}"
  force_destroy = true
  tags = { Projeto = "Aula25", Laboratorio = "GlueWorkflow" }
}
resource "aws_s3_bucket_public_access_block" "zones" {
  for_each = aws_s3_bucket.zones
  bucket = each.value.id
  block_public_acls = true
  block_public_policy = true
  ignore_public_acls = true
  restrict_public_buckets = true
}
resource "aws_s3_bucket_server_side_encryption_configuration" "zones" {
  for_each = aws_s3_bucket.zones
  bucket = each.value.id
  rule { apply_server_side_encryption_by_default { sse_algorithm = "AES256" } }
}
resource "aws_s3_bucket_versioning" "bronze" {
  bucket = aws_s3_bucket.zones["bronze"].id
  versioning_configuration { status = "Enabled" }
}
resource "aws_glue_catalog_database" "db" { name = local.db }
resource "aws_glue_catalog_table" "tables" {
  for_each = local.schemas
  name = each.key
  database_name = aws_glue_catalog_database.db.name
  table_type = "EXTERNAL_TABLE"
  parameters = { EXTERNAL = "TRUE", classification = "parquet" }
  storage_descriptor {
    location = "s3://${aws_s3_bucket.zones[each.value.zone].id}/${each.key}/"
    input_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
    ser_de_info { serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe" }
    dynamic "columns" {
      for_each = each.value.cols
      content {
        name = columns.key
        type = columns.value
      }
    }
  }
}
resource "aws_athena_workgroup" "lab" {
  name = var.project
  force_destroy = true
  configuration {
    enforce_workgroup_configuration = true
    bytes_scanned_cutoff_per_query = 104857600
    engine_version { selected_engine_version = "Athena engine version 3" }
    result_configuration {
      output_location = "s3://${aws_s3_bucket.zones["results"].id}/athena/"
      encryption_configuration { encryption_option = "SSE_S3" }
    }
  }
}
resource "aws_s3_object" "scripts" {
  for_each = toset(["silver.py", "gold.py"])
  bucket = aws_s3_bucket.zones["results"].id
  key = "scripts/${each.value}"
  source = "${path.module}/jobs/${each.value}"
  etag = filemd5("${path.module}/jobs/${each.value}")
}
resource "aws_glue_job" "etl" {
  for_each = toset(["silver", "gold"])
  name = "${var.project}-${each.key}"
  role_arn = var.glue_role_arn
  glue_version = "4.0"
  worker_type = "G.1X"
  number_of_workers = 2
  timeout = 15
  max_retries = 0
  execution_property { max_concurrent_runs = 1 }
  command {
    name = "glueetl"
    script_location = "s3://${aws_s3_object.scripts["${each.key}.py"].bucket}/${aws_s3_object.scripts["${each.key}.py"].key}"
    python_version = "3"
  }
  default_arguments = {
    "--job-language" = "python"
    "--job-bookmark-option" = "job-bookmark-disable"
    "--enable-metrics" = "true"
    "--BRONZE" = aws_s3_bucket.zones["bronze"].id
    "--SILVER" = aws_s3_bucket.zones["silver"].id
    "--GOLD" = aws_s3_bucket.zones["gold"].id
    "--RESULTS" = aws_s3_bucket.zones["results"].id
    "--DATABASE" = aws_glue_catalog_database.db.name
  }
}
resource "aws_glue_workflow" "pipeline" {
  name = "${var.project}-pipeline"
  max_concurrent_runs = 1
}
resource "aws_glue_trigger" "start" {
  name = "${var.project}-start"
  type = "ON_DEMAND"
  workflow_name = aws_glue_workflow.pipeline.name
  actions { job_name = aws_glue_job.etl["silver"].name }
}
resource "aws_glue_trigger" "gold_after_silver" {
  name = "${var.project}-silver-ok"
  type = "CONDITIONAL"
  workflow_name = aws_glue_workflow.pipeline.name
  start_on_creation = true
  predicate {
    conditions {
      job_name = aws_glue_job.etl["silver"].name
      state = "SUCCEEDED"
    }
  }
  actions { job_name = aws_glue_job.etl["gold"].name }
}
output "region" { value = var.region }
output "database" { value = aws_glue_catalog_database.db.name }
output "workgroup" { value = aws_athena_workgroup.lab.name }
output "workflow" { value = aws_glue_workflow.pipeline.name }
output "buckets" { value = { for k, v in aws_s3_bucket.zones : k => v.id } }
output "jobs" { value = { for k, v in aws_glue_job.etl : k => v.name } }
