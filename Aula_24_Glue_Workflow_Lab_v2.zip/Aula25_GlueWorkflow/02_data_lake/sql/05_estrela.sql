-- Esquema estrela: FATO (pedido x item) com dimensoes explicitas da Gold.
SELECT t.ano, t.mes, c.canal, u.uf, p.categoria,
       SUM(f.receita_liquida) AS receita
FROM fato_vendas f
JOIN dim_produto p ON f.produto_id = p.produto_id
JOIN dim_tempo t ON f.data = t.data
JOIN dim_canal c ON f.canal = c.canal
JOIN dim_uf u ON f.uf = u.uf
GROUP BY t.ano, t.mes, c.canal, u.uf, p.categoria
ORDER BY c.canal, u.uf, p.categoria;
