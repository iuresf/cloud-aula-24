-- Pergunta A: quanto a empresa faturou de fato (apos estornos)?
SELECT canal, SUM(receita_liquida) AS receita
FROM indicadores_vendas GROUP BY canal ORDER BY canal;

-- Pergunta B: onde/categoria esta a receita? (nao misturar grao de sessao!)
SELECT uf, categoria, SUM(receita_liquida) AS receita
FROM indicadores_vendas GROUP BY uf, categoria ORDER BY uf, categoria;

-- Pergunta C: qual canal converte mais sessoes? 2 dias somados com pesos.
SELECT canal, SUM(sessoes) AS sessoes,
       SUM(sessoes_convertidas) AS conversoes,
       ROUND(100.0 * SUM(sessoes_convertidas) / SUM(sessoes), 1) AS taxa_pct
FROM indicadores_funil GROUP BY canal ORDER BY canal;

-- Pergunta D: como o estorno de 12/11 altera a venda de 10/11?
SELECT pedido_id, data, status_pagamento, valor_bruto, receita_liquida
FROM fato_vendas WHERE pedido_id IN ('P1002','P1003') ORDER BY pedido_id;
