-- Duplicata de evento EV04 entrou duas vezes, mas na Silver fica 1.
SELECT evento_id, COUNT(*) AS n FROM eventos
GROUP BY evento_id HAVING COUNT(*) > 1;

-- Um item de pedido deve aparecer uma vez na Silver.
SELECT pedido_id, item_id, COUNT(*) AS n FROM pedidos
GROUP BY pedido_id, item_id HAVING COUNT(*) > 1;

-- Pagamento atual escolhido pela data da ultima transicao.
SELECT pedido_id, resultado, atualizado_em, source_key
FROM pagamentos ORDER BY pedido_id;
