-- 1) Linha Gold mostra as origens efetivamente usadas.
SELECT pedido_id, status_pagamento, receita_liquida,
       pedido_source_key, pagamento_source_key, produto_source_key
FROM fato_vendas WHERE pedido_id = 'P1002';

-- 2) Descobrir qual lote de pagamento fez o estorno.
SELECT pedido_id, resultado, source_key, source_record_id, batch_id
FROM pagamentos WHERE pedido_id = 'P1002';

-- 3) Pegar a key retornada e consultar manifestos/bronze no S3:
--   key = pagamentos/lote_002.jsonl
--   version_id = versao exata preservada pelo versionamento S3
--   sha256 = digest do arquivo ingerido
-- 4) Manifestos Silver e Gold com mesmo workflow_run_id:
--   s3://<results>/manifestos/silver/<workflow_run_id>.json
--   s3://<results>/manifestos/gold/<workflow_run_id>.json
