-- Na console Athena selecione o workgroup e o database Terraform.
SELECT 'pedidos' AS fonte, count(*) AS registros FROM pedidos
UNION ALL SELECT 'produtos', count(*) FROM produtos
UNION ALL SELECT 'pagamentos_atuais', count(*) FROM pagamentos
UNION ALL SELECT 'eventos_unicos', count(*) FROM eventos;

-- Execute separadamente para inspecionar uma linha Silver com linhagem:
SELECT pedido_id, item_id, source_key, source_record_id, batch_id
FROM pedidos ORDER BY pedido_id;
