"""Bronze -> Silver. Reprocessamento integral didatico e linhagem por registro."""
import json
import sys
from datetime import datetime, timezone

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import Window, functions as F

args = getResolvedOptions(sys.argv, [
    "JOB_NAME", "BRONZE", "SILVER", "GOLD", "RESULTS", "DATABASE",
    "WORKFLOW_NAME", "WORKFLOW_RUN_ID",
])
ctx = GlueContext(SparkContext.getOrCreate())
spark = ctx.spark_session
spark.conf.set("spark.sql.session.timeZone", "UTC")
job = Job(ctx)
job.init(args["JOB_NAME"], args)
s3 = boto3.client("s3")
glue = boto3.client("glue")
props = glue.get_workflow_run_properties(
    Name=args["WORKFLOW_NAME"], RunId=args["WORKFLOW_RUN_ID"]
)["RunProperties"]
batch = props["batch_id"]
bronze = args["BRONZE"]
silver = args["SILVER"]


def origin(df, name, record):
    return (df.withColumn("source_key", F.regexp_extract(F.input_file_name(), rf"({name}/[^?]+)$", 1))
            .withColumn("source_record_id", record)
            .withColumn("batch_id", F.regexp_extract("source_key", r"lote_(\d+)", 1)))


def require(df, expression, message):
    if df.filter(expression).limit(1).count():
        raise ValueError(message + " (Gold nao sera disparada)")


def csv_data(name, schema):
    df = spark.read.option("header", "true").option("sep", ";").schema(schema).csv(
        f"s3://{bronze}/{name}/"
    )
    return df


pedidos = origin(csv_data("pedidos",
    "pedido_id string,item_id string,data_pedido string,produto_id string,"
    "quantidade string,preco_unitario string,canal string,uf string,atualizado_em string"),
    "pedidos", F.concat_ws("/", "pedido_id", "item_id"))
pedidos = pedidos.select(
    "pedido_id", "item_id", F.to_date("data_pedido").alias("data"), "produto_id",
    F.col("quantidade").cast("int").alias("quantidade"),
    F.col("preco_unitario").cast("decimal(12,2)").alias("preco_unitario"),
    F.lower(F.trim("canal")).alias("canal"), F.upper(F.trim("uf")).alias("uf"),
    F.to_timestamp("atualizado_em").alias("atualizado_em"),
    "source_key", "source_record_id", "batch_id")
require(pedidos, "pedido_id IS NULL OR item_id IS NULL OR data IS NULL OR produto_id IS NULL "
    "OR quantidade IS NULL OR quantidade <= 0 OR preco_unitario IS NULL OR preco_unitario < 0 "
    "OR atualizado_em IS NULL OR canal NOT IN ('web','app','marketplace') OR uf IS NULL",
    "Pedido invalido")
pedidos = (pedidos.withColumn("rn", F.row_number().over(
    Window.partitionBy("pedido_id", "item_id").orderBy(
        F.col("atualizado_em").desc(), F.col("source_key").desc())))
    .filter("rn=1").drop("rn", "atualizado_em"))

produtos = origin(csv_data("produtos", "produto_id string,nome string,categoria string"),
    "produtos", F.col("produto_id"))
require(produtos, "produto_id IS NULL OR nome IS NULL OR categoria IS NULL", "Produto invalido")
require(produtos.groupBy("produto_id").count(), "count > 1", "Produto repetido no catalogo")
require(pedidos.join(produtos, "produto_id", "left_anti"), "produto_id IS NOT NULL",
    "Pedido com produto sem cadastro")

pagamentos = origin(spark.read.schema(
    "evento_id string,pedido_id string,resultado string,atualizado_em string"
).json(f"s3://{bronze}/pagamentos/"), "pagamentos", F.col("evento_id"))
pagamentos = pagamentos.withColumn("atualizado_em", F.to_timestamp("atualizado_em"))
require(pagamentos, "evento_id IS NULL OR pedido_id IS NULL OR atualizado_em IS NULL "
    "OR resultado NOT IN ('aprovado','pendente','estornado')", "Pagamento invalido")
require(pagamentos.groupBy("evento_id").agg(F.countDistinct("resultado").alias("n")),
    "n > 1", "Mesmo evento de pagamento com resultados conflitantes")
require(pagamentos.groupBy("pedido_id", "atualizado_em").agg(
    F.countDistinct("resultado").alias("n")), "n > 1", "Pagamento em empate contraditorio")
pagamentos = pagamentos.withColumn("rn", F.row_number().over(
    Window.partitionBy("pedido_id").orderBy(
        F.col("atualizado_em").desc(), F.col("evento_id").desc()))).filter("rn=1").drop("rn")

eventos = origin(spark.read.schema(
    "evento_id string,sessao string,data string,canal string,evento string,pedido_id string"
).json(f"s3://{bronze}/eventos/"), "eventos", F.col("evento_id"))
eventos = eventos.withColumn("data", F.to_date("data"))
require(eventos, "evento_id IS NULL OR sessao IS NULL OR data IS NULL OR canal IS NULL "
    "OR evento NOT IN ('visita','checkout')", "Evento de navegacao invalido")
require(eventos.groupBy("evento_id").agg(
    F.countDistinct(F.concat_ws("|", "sessao", "canal", "evento", F.coalesce("pedido_id", F.lit("")))
    ).alias("n")), "n > 1", "Evento duplicado com payload divergente")
eventos = eventos.withColumn("rn", F.row_number().over(
    Window.partitionBy("evento_id").orderBy("source_key"))).filter("rn=1").drop("rn")

datasets = {
    "pedidos": pedidos, "produtos": produtos,
    "pagamentos": pagamentos, "eventos": eventos,
}
counts = {}
sources = {}
for name, frame in datasets.items():
    counts[name] = frame.count()
    sources[name] = [r[0] for r in frame.select("source_key").distinct().collect()]
    frame.coalesce(1).write.mode("overwrite").parquet(f"s3://{silver}/{name}/")

used_files = sorted(set(key for keys in sources.values() for key in keys))
source_versions = []
for key in used_files:
    metadata = s3.head_object(Bucket=bronze, Key=key)
    source_versions.append({
        "key": key, "version_id": metadata.get("VersionId"),
        "sha256": metadata.get("Metadata", {}).get("sha256"),
    })
manifest = {
    "camada": "silver", "workflow_run_id": args["WORKFLOW_RUN_ID"],
    "workflow_name": args["WORKFLOW_NAME"], "batch_id": batch,
    "bronze_manifest": props["bronze_manifest"],
    "glue_job": args["JOB_NAME"], "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    "quantidades": counts, "origens": sources, "arquivos_bronze": source_versions,
    "destinos": [f"s3://{silver}/{name}/" for name in datasets],
    "politica": "snapshot completo; dedupe por chave; pagamento mais recente; sem bookmarks",
}
key = f"manifestos/silver/{args['WORKFLOW_RUN_ID']}.json"
s3.put_object(Bucket=args["RESULTS"], Key=key,
              Body=json.dumps(manifest, ensure_ascii=False).encode("utf-8"),
              ContentType="application/json")
job.commit()
