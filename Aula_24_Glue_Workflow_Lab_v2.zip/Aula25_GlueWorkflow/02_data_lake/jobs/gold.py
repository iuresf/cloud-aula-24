"""Silver -> Gold: estrela simples de vendas e funil SEM multiplicar sessoes por item."""
import json
import sys
from datetime import datetime, timezone

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, [
    "JOB_NAME", "BRONZE", "SILVER", "GOLD", "RESULTS", "DATABASE",
    "WORKFLOW_NAME", "WORKFLOW_RUN_ID",
])
ctx = GlueContext(SparkContext.getOrCreate())
spark = ctx.spark_session
spark.conf.set("spark.sql.session.timeZone", "UTC")
job = Job(ctx)
job.init(args["JOB_NAME"], args)
glue, s3 = boto3.client("glue"), boto3.client("s3")
props = glue.get_workflow_run_properties(
    Name=args["WORKFLOW_NAME"], RunId=args["WORKFLOW_RUN_ID"]
)["RunProperties"]
silver_manifest_key = f"manifestos/silver/{args['WORKFLOW_RUN_ID']}.json"
silver_manifest = json.loads(s3.get_object(
    Bucket=args["RESULTS"], Key=silver_manifest_key)["Body"].read())
if silver_manifest["workflow_run_id"] != args["WORKFLOW_RUN_ID"]:
    raise ValueError("Gold bloquearia uma Silver antiga.")

base = f"s3://{args['SILVER']}"
pedidos = spark.read.parquet(f"{base}/pedidos/")
produtos = spark.read.parquet(f"{base}/produtos/")
pagamentos = spark.read.parquet(f"{base}/pagamentos/")
eventos = spark.read.parquet(f"{base}/eventos/")
fato = (pedidos.alias("p")
    .join(produtos.alias("pr"), F.col("p.produto_id") == F.col("pr.produto_id"), "inner")
    .join(pagamentos.alias("pg"), F.col("p.pedido_id") == F.col("pg.pedido_id"), "left"))
fato = fato.select(
    F.col("p.pedido_id").alias("pedido_id"), F.col("p.item_id").alias("item_id"),
    F.col("p.data").alias("data"), F.col("p.produto_id").alias("produto_id"),
    F.col("pr.categoria").alias("categoria"), F.col("p.canal").alias("canal"),
    F.col("p.uf").alias("uf"), F.col("p.quantidade").alias("quantidade"),
    (F.col("p.quantidade") * F.col("p.preco_unitario")).cast("decimal(14,2)").alias("valor_bruto"),
    F.coalesce(F.col("pg.resultado"), F.lit("sem_pagamento")).alias("status_pagamento"),
    F.when(F.col("pg.resultado") == "aprovado",
        F.col("p.quantidade") * F.col("p.preco_unitario")
    ).otherwise(F.lit(0)).cast("decimal(14,2)").alias("receita_liquida"),
    F.col("p.source_key").alias("pedido_source_key"),
    F.col("pg.source_key").alias("pagamento_source_key"),
    F.col("pr.source_key").alias("produto_source_key"),
    F.col("p.batch_id").alias("batch_id"))

vendas = fato.groupBy("data", "canal", "uf", "categoria").agg(
    F.countDistinct("pedido_id").cast("bigint").alias("pedidos"),
    F.countDistinct(F.when(F.col("status_pagamento") == "aprovado",
                           F.col("pedido_id"))).cast("bigint").alias("pagos"),
    F.sum("receita_liquida").cast("decimal(14,2)").alias("receita_liquida"))

# Uma sessao tem apenas uma contagem, independentemente da quantidade de itens.
validos = fato.filter("status_pagamento = 'aprovado'").select("pedido_id").distinct()
visitas = eventos.groupBy("data", "canal").agg(
    F.countDistinct("sessao").cast("bigint").alias("sessoes"))
convertidas = (eventos.filter("evento = 'checkout'")
    .join(validos, "pedido_id", "inner").groupBy("data", "canal")
    .agg(F.countDistinct("sessao").cast("bigint").alias("sessoes_convertidas")))
funil = (visitas.join(convertidas, ["data", "canal"], "left")
    .fillna(0, subset=["sessoes_convertidas"])
    .withColumn("conversao", F.col("sessoes_convertidas") / F.col("sessoes")))

datasets = {
    "fato_vendas": fato.drop("categoria"),
    "dim_produto": produtos.select("produto_id", "nome", "categoria").distinct(),
    "dim_tempo": pedidos.select("data").distinct()
        .withColumn("ano", F.year("data")).withColumn("mes", F.month("data")),
    "dim_canal": pedidos.select("canal").distinct(),
    "dim_uf": pedidos.select("uf").distinct(),
    "indicadores_vendas": vendas,
    "indicadores_funil": funil,
}
counts = {}
for name, frame in datasets.items():
    counts[name] = frame.count()
    frame.coalesce(1).write.mode("overwrite").parquet(f"s3://{args['GOLD']}/{name}/")

manifest = {
    "camada": "gold", "workflow_run_id": args["WORKFLOW_RUN_ID"],
    "batch_id": props["batch_id"], "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    "glue_job": args["JOB_NAME"], "silver_manifest": silver_manifest_key,
    "bronze_manifest": silver_manifest["bronze_manifest"], "quantidades": counts,
    "destinos": [f"s3://{args['GOLD']}/{name}/" for name in datasets],
    "resultado": "snapshot atual de vendas e conversoes; nao e historico transacional",
}
s3.put_object(Bucket=args["RESULTS"],
              Key=f"manifestos/gold/{args['WORKFLOW_RUN_ID']}.json",
              Body=json.dumps(manifest, ensure_ascii=False).encode("utf-8"),
              ContentType="application/json")
job.commit()
