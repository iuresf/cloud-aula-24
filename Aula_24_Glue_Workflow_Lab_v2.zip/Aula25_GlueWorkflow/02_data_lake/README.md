# Infraestrutura da Aula 25 — alternativa Glue Workflow

- Terraform provisiona quatro buckets privados e criptografados S3: Bronze (versionado), Silver, Gold e Results. Atenção: `force_destroy = true`, só usar em projeto isolado de laboratório.
- Role IAM para Glue **não é criada** (Learner Lab costuma restringir criação de roles); informe `glue_role_arn` existente autorizada. Ela precisa ler Bronze, ler/gravar Silver/Gold/Results, ler scripts e criar logs; usuários precisam de permissões para Terraform e Athena.
- Data Catalog: onze tabelas de schema fixo (quatro Silver, uma fato Gold, quatro dimensões Gold e dois indicadores Gold), criadas via Terraform e apontando a prefixos S3 Parquet. **Não é necessário executar Crawler** a cada lote enquanto o schema não muda; se esquema/prefixo mudar, altere metadados.
- Workflow `<project>-pipeline` com start on-demand → Silver; condicional SUCCEEDED → Gold. Se Silver falhar, Gold não inicia. A identidade `WORKFLOW_RUN_ID` permite que Gold rejeite manifesto Silver de execução anterior.
- Jobs Glue 4.0, 2 workers G.1X, execução isolada; bookmarks desabilitados para permitir recomputação de dados históricos depois de estorno tardio.
- Athena: engine v3, workgroup com teto por consulta de 100 MiB e output em Results.

`terraform.tfvars.example` é um **modelo**, substitua o ARN antes de aplicar.

Para inspecionar o grafo: AWS Glue → Workflows → `a25-workflow-pipeline`. O Job Gold só deve aparecer após a conclusão de Silver no **mesmo workflow run**. Não execute jobs diretamente via console se quiser observar o gatilho condicionado.
