"""Figuras vetoriais autorais, geradas para os slides da aula."""
from html import escape
from pathlib import Path

ROOT = Path(__file__).parent / "figuras"
ROOT.mkdir(exist_ok=True)
NAVY, BLUE, TEAL, GREEN, AMBER, RED = "#15345D", "#2576B7", "#0B8D92", "#238356", "#D08B24", "#BE4E49"
BG, WHITE, TXT, PALE = "#F5F8FC", "#FFFFFF", "#203A58", "#DCE6F1"


def doc():
    return ['<svg xmlns="http://www.w3.org/2000/svg" width="2000" height="770" viewBox="0 0 2000 770">',
            '<rect width="2000" height="770" fill="#F5F8FC"/>',
            '<style>text{font-family:DejaVu Sans,Arial,sans-serif}</style>']


def rect(x, y, w, h, fill=WHITE, stroke=PALE, r=22):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="2"/>'


def txt(x, y, s, size=29, color=TXT, weight=500):
    return f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}">{escape(s)}</text>'


def arrow(x1, y1, x2, y2, color=BLUE):
    return (f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="7" stroke-linecap="round"/>'
            f'<path d="M{x2-13} {y2-11} L{x2} {y2} L{x2-13} {y2+11}" stroke="{color}" stroke-width="6" fill="none"/>')


def lines(x, y, strings, color=TXT, step=43, size=28):
    return [txt(x, y + step * i, st, size=size, color=color) for i, st in enumerate(strings)]


def save(name, a):
    a.append("</svg>")
    (ROOT / name).write_text("\n".join(a), encoding="utf8")


a = doc()
a += [txt(45, 65, "ALTERNATIVA EXECUTÁVEL | ingestão em lote + Glue Workflow", 39, NAVY, 700)]
a += [rect(30, 115, 320, 530), txt(53, 165, "FONTES (4)", 34, NAVY, 700)]
for idx, (t, sub) in enumerate([("Pedidos", "CSV • 6 pedidos"), ("Pagamentos", "JSONL • estorno"), ("Navegação", "JSONL • sessões"), ("Produtos", "CSV • categoria")]):
    y = 195 + idx * 103
    a += [rect(51, y, 278, 85, "#EEF5FB", "#C8D9EA", 14),
          txt(69, y+35, t, 27, NAVY, 700), txt(69, y+65, sub, 22, TXT)]
a += [arrow(357, 376, 420, 376)]
a += [rect(430, 220, 275, 320, "#EAF4FC", "#83B4DB"), txt(467, 285, "S3 BRONZE", 32, BLUE, 700)]
a += lines(461, 335, ["lote_001", "lote_002", "versionamento S3", "manifesto de entrada"], BLUE, size=22)
a += [arrow(708, 376, 771, 376)]
a += [rect(785, 120, 705, 525, "#EDF6F2", "#8DCCB0"),
      txt(817, 173, "AWS GLUE WORKFLOW", 34, GREEN, 700)]
a += [rect(813, 220, 298, 242, WHITE, "#95BDA6"), txt(845, 279, "JOB SILVER", 32, GREEN, 700)]
a += lines(837, 322, ["validação + dedupe", "4 Parquets", "linhagem por linha"], TXT, step=40, size=24)
a += [arrow(1119, 339, 1174, 339, GREEN)]
a += [rect(1180, 220, 270, 242, WHITE, "#95BDA6"), txt(1210, 279, "JOB GOLD", 32, GREEN, 700)]
a += lines(1205, 322, ["fato + 4 dimensões", "receita por canal/UF", "funil sem duplicar"], TXT, step=40, size=22)
a += [txt(851, 520, "Gatilho: Gold após SILVER = SUCCEEDED", 23, GREEN, 700),
      txt(871, 572, "run_id comum e manifestos por camada", 24, TXT)]
a += [arrow(1497, 376, 1555, 376)]
a += [rect(1566, 220, 405, 320, "#FFF8EB", "#E5C18D"),
      txt(1603, 282, "GLUE CATALOG", 30, AMBER, 700),
      txt(1603, 332, "prefixos + schemas", 25, TXT),
      txt(1603, 413, "AMAZON ATHENA", 30, AMBER, 700),
      txt(1603, 462, "SQL sobre a Gold", 26, TXT)]
a += [rect(397, 677, 1240, 60, "#E7EBF5", "#E7EBF5", 16),
      txt(427, 717, "AWS Academy: runner.py substitui API/SQS na entrada; sem IAM novo nem Crawler.", 27, NAVY, 600)]
save("workflow_arquitetura.svg", a)

a = doc()
a += [txt(45, 60, "RASTREABILIDADE | de um estorno no arquivo até a resposta SQL", 38, NAVY, 700)]
cols = [
    (35, 420, "BRONZE", BLUE, ["lote_001: PG02", "P1002 aprovado", "lote_002: PG05", "P1002 estornado", "manifesto: key, SHA,", "versionId do objeto"]),
    (495, 425, "SILVER", GREEN, ["pagamentos Parquet", "P1002: estornado", "source_key:", "pagamentos/lote_002", ".jsonl; record PG05", "manifesto Silver/run"]),
    (963, 438, "GOLD", TEAL, ["fato_vendas Parquet", "P1002: valor R$ 120", "receita_liquida R$ 0", "pagamento_source_key", "= lote_002", "manifesto Gold/run"]),
    (1442, 523, "ATHENA", AMBER, ["WHERE pedido_id=", "'P1002'", "status = estornado", "receita = R$ 0", "outros pedidos = R$ 610", "na carga final"]),
]
for x, w, title, color, content in cols:
    a += [rect(x, 130, w, 485, WHITE, color), rect(x+15, 150, w-30, 69, color, color, 14),
          txt(x+34, 198, title, 31, WHITE, 700)]
    a += lines(x+28, 282, content, color=TXT, step=51, size=25)
for (x1,x2) in [(458,487), (922,954), (1406,1433)]:
    a += [arrow(x1, 360, x2, 360)]
a += [rect(250, 659, 1500, 69, "#E9EDF6", "#E9EDF6", 12),
      txt(306, 705, "workflow_run_id conecta Silver/Gold; source_key conecta a linha ao manifesto Bronze.", 26, NAVY, 600)]
save("workflow_rastreio.svg", a)
