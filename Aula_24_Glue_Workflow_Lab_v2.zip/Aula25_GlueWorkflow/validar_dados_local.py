"""Checagem local independente dos dados de entrada (sem boto3 ou Spark)."""
import csv
import json
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

base = Path(__file__).parent / "dados"
expected = json.loads((Path(__file__).parent / "resultados_esperados.json").read_text())


def collect(stage, name):
    result = []
    for part in ("inicial", "delta"):
        if part == "delta" and stage == "inicial":
            continue
        folder = base / part / name
        for file in sorted(folder.glob("*")):
            if file.suffix == ".csv":
                with file.open(encoding="utf8", newline="") as f:
                    result.extend(csv.DictReader(f, delimiter=";"))
            else:
                result.extend(json.loads(line) for line in file.read_text().splitlines())
    return result


for stage in ("inicial", "delta"):
    orders = collect(stage, "pedidos")
    pays = collect(stage, "pagamentos")
    visits = collect(stage, "eventos")
    assert len({(r["pedido_id"], r["item_id"]) for r in orders}) == len(orders)
    latest = {}
    for p in pays:
        key = p["pedido_id"]
        if key not in latest or latest[key]["atualizado_em"] < p["atualizado_em"]:
            latest[key] = p
    value = sum((Decimal(r["preco_unitario"]) * int(r["quantidade"])
                 for r in orders if latest.get(r["pedido_id"], {}).get("resultado") == "aprovado"),
                Decimal("0"))
    paid = len({r["pedido_id"] for r in orders
                if latest.get(r["pedido_id"], {}).get("resultado") == "aprovado"})
    sessions = len({r["sessao"] for r in visits})
    target = expected[stage]
    assert (len(orders), paid, sessions, value) == (
        target["pedidos"], target["pagos"], target["sessoes"], Decimal(target["receita"]))
    print(f"{stage}: pedidos={len(orders)}, pagos={paid}, sessoes={sessions}, receita={value}")
    if stage == "delta":
        events = defaultdict(int)
        for row in visits:
            events[row["evento_id"]] += 1
        assert events["EV04"] == 2, "Delta precisa incluir repeticao para mostrar dedupe"
        assert latest["P1002"]["resultado"] == "estornado"
        assert latest["P1002"]["evento_id"] == "PG05"
        assert latest["P1003"]["resultado"] == "aprovado"
        channel = {}
        for name in ("web", "app", "marketplace"):
            revenue = sum((Decimal(r["preco_unitario"]) * int(r["quantidade"])
                for r in orders if r["canal"] == name and
                latest.get(r["pedido_id"], {}).get("resultado") == "aprovado"), Decimal("0"))
            unique = {v["sessao"] for v in visits if v["canal"] == name}
            conv = {v["sessao"] for v in visits if v["canal"] == name and
                    v["evento"] == "checkout" and
                    latest.get(v["pedido_id"], {}).get("resultado") == "aprovado"}
            exp = expected["apos_delta_canais"][name]
            assert (revenue, len(unique), len(conv)) == (
                Decimal(exp["receita"]), exp["sessoes"], exp["convertidas"])
            channel[name] = (revenue, len(conv), len(unique))
        print("por canal:", channel)
print("OK: perguntas de negocio e rastreio P1002 consistentes.")
