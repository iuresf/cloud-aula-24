"""AWS Academy: arquivos -> S3 Bronze -> Glue Workflow -> Athena.

O runner NAO inicia Jobs individualmente: so workflow_start, necessario para
que o gatilho condicional observe SUCCEEDED da Silver.
"""
import argparse
import hashlib
import json
import subprocess
import time
import uuid
from decimal import Decimal
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parent
INFRA = ROOT / "02_data_lake"
parser = argparse.ArgumentParser(description="Aula 25 - Glue Workflow")
parser.add_argument("action", choices=["initial", "delta", "verify", "trace", "cleanup"])
parser.add_argument("--pedido", default="P1002")
args = parser.parse_args()
outputs = {
    k: v["value"] for k, v in json.loads(subprocess.check_output(
        ["terraform", "output", "-json"], cwd=INFRA)).items()
}
session = boto3.Session(region_name=outputs["region"])
s3, glue, athena = (session.client(name) for name in ["s3", "glue", "athena"])
ev = INFRA / "evidencias"
ev.mkdir(exist_ok=True)
invocation = str(uuid.uuid4())


def record(kind, value):
    (ev / f"{invocation}-{kind}.json").write_text(
        json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )


def upload(stage):
    batch_code = "001" if stage == "inicial" else "002"
    bucket = outputs["buckets"]["bronze"]
    files = []
    for file in sorted((ROOT / "dados" / stage).rglob("*")):
        if not file.is_file():
            continue
        key = file.relative_to(ROOT / "dados" / stage).as_posix()
        body = file.read_bytes()
        digest = hashlib.sha256(body).hexdigest()
        try:
            old = s3.head_object(Bucket=bucket, Key=key)
            if old.get("Metadata", {}).get("sha256") != digest:
                raise ValueError(f"Objeto Bronze ja existe com conteudo diferente: {key}")
            version = old.get("VersionId")
        except ClientError as exc:
            if exc.response["Error"]["Code"] not in ("404", "NoSuchKey", "NotFound"):
                raise
            written = s3.put_object(Bucket=bucket, Key=key, Body=body,
                                    Metadata={"sha256": digest})
            version = written.get("VersionId")
        files.append({"s3_uri": f"s3://{bucket}/{key}", "key": key,
                      "version_id": version, "sha256": digest, "bytes": len(body)})
    if not files:
        raise ValueError("Lote vazio.")
    key = f"manifestos/bronze/{invocation}.json"
    manifest = {"camada": "bronze", "batch_id": batch_code, "ingestion_id": invocation,
                "files": files, "regra": "objetos imutaveis por lote; reaplicacao idempotente"}
    s3.put_object(Bucket=outputs["buckets"]["results"], Key=key,
                  Body=json.dumps(manifest, ensure_ascii=False).encode("utf-8"),
                  ContentType="application/json")
    record("bronze", manifest)
    return key


def workflow(bronze_manifest, stage):
    batch_code = "001" if stage == "initial" else "002"
    runid = glue.start_workflow_run(Name=outputs["workflow"], RunProperties={
        "bronze_manifest": bronze_manifest,
        "batch_id": batch_code,
    })["RunId"]
    print(f"Workflow iniciado: {outputs['workflow']} / {runid}", flush=True)
    deadline = time.monotonic() + 1800
    while time.monotonic() < deadline:
        state = glue.get_workflow_run(Name=outputs["workflow"], RunId=runid,
                                      IncludeGraph=True)["Run"]
        status = state["Status"]
        if status == "COMPLETED":
            for layer in ("silver", "gold"):
                key = f"manifestos/{layer}/{runid}.json"
                try:
                    s3.head_object(Bucket=outputs["buckets"]["results"], Key=key)
                except ClientError as exc:
                    raise RuntimeError(f"Workflow terminou sem manifesto {layer}: {key}") from exc
            record("workflow", state)
            return runid
        if status in ("ERROR", "STOPPED", "STOPPING"):
            record("falha", state)
            raise RuntimeError(f"Workflow falhou: {status}. Verifique Glue Runs.")
        time.sleep(15)
    raise TimeoutError(f"Workflow excedeu 30 min: {runid}")


def query(sql):
    qid = athena.start_query_execution(
        QueryString=sql,
        QueryExecutionContext={"Database": outputs["database"]},
        WorkGroup=outputs["workgroup"])["QueryExecutionId"]
    deadline = time.monotonic() + 300
    while time.monotonic() < deadline:
        state = athena.get_query_execution(QueryExecutionId=qid)["QueryExecution"]
        status = state["Status"]["State"]
        if status == "SUCCEEDED":
            result = []
            token = None
            while True:
                opts = {"QueryExecutionId": qid}
                if token:
                    opts["NextToken"] = token
                page = athena.get_query_results(**opts)
                result.extend([[cell.get("VarCharValue") for cell in row["Data"]]
                               for row in page["ResultSet"]["Rows"]])
                token = page.get("NextToken")
                if not token:
                    break
            record("athena-" + qid, {"sql": sql, "rows": result,
                                   "statistics": state.get("Statistics")})
            return result
        if status in ("FAILED", "CANCELLED"):
            raise RuntimeError(state["Status"])
        time.sleep(3)
    raise TimeoutError(qid)


def verify(expected=None):
    values = query("SELECT COUNT(DISTINCT pedido_id) AS n, SUM(receita_liquida) AS receita "
                   "FROM fato_vendas WHERE status_pagamento='aprovado'")
    count, revenue = int(values[1][0]), Decimal(values[1][1])
    n = int(query("SELECT COUNT(*) FROM pedidos")[1][0])
    sessions = int(query("SELECT SUM(sessoes) FROM indicadores_funil")[1][0])
    if expected == "initial":
        assert (count, revenue, n, sessions) == (3, Decimal("480.00"), 4, 7)
    elif expected == "delta":
        assert (count, revenue, n, sessions) == (5, Decimal("610.00"), 6, 10)
    assert n in (4, 6)
    assert (count, revenue, sessions) in (
        (3, Decimal("480.00"), 7), (5, Decimal("610.00"), 10))
    print(f"VALIDADO: pedidos={n}, pagos={count}, receita={revenue}, sessoes={sessions}")
    return {"pedidos": n, "pagos": count, "receita": str(revenue), "sessoes": sessions}


def trace(order_id):
    rows = query(
        "SELECT pedido_id, status_pagamento, CAST(receita_liquida AS varchar), "
        "pedido_source_key, pagamento_source_key, produto_source_key "
        f"FROM fato_vendas WHERE pedido_id = '{order_id.replace(chr(39), '')}'"
    )
    print(json.dumps(rows, ensure_ascii=False, indent=2))
    print("O source_key de cada linha localiza a origem no manifesto Bronze, "
          "que possui version_id e sha256. O workflow_run_id conecta "
          "manifestos Silver e Gold no bucket results/manifestos/.")
    return rows


if args.action in ("initial", "delta"):
    manifest_key = upload("inicial" if args.action == "initial" else "delta")
    workflow(manifest_key, args.action)
    verify(args.action)
elif args.action == "verify":
    verify()
elif args.action == "trace":
    trace(args.pedido)
else:
    print("Para limpar: cd 02_data_lake && terraform plan -destroy; "
          "revise os alvos antes de terraform destroy.")
