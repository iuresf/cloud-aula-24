# Validação e investigação didática

## Sem conta AWS (simulação determinística)

`python gerar_dados.py` → `python validar_dados_local.py`.
Essa validação testa o conjunto de entrada e calcula receitas e sessões esperadas, mas **não substitui** a execução AWS Glue.

## Na AWS

1. Após `runner.py initial`, validar 4 pedidos e R$ 480.
2. Após `runner.py delta`, validar 6 pedidos e R$ 610, 10 sessões.
3. Athena `03_qualidade.sql`: consultas de duplicata de `evento_id` e `(pedido_id,item_id)` devem retornar **zero linhas**.
4. Athena `04_rastreabilidade.sql`: P1002 deve ter `receita_liquida=0`, `status_pagamento=estornado`, `pagamento_source_key=pagamentos/lote_002.jsonl`.
5. Em `Results/manifestos/bronze/<ingestion_id>.json`, localize a key acima e seu `sha256` e `version_id`. Em `Results/manifestos/silver/<workflow_run_id>.json` e `gold/<workflow_run_id>.json`, verifique a cadeia de execução, não confunda esses manifestos com linhas Parquet.
6. S3 Silver `/pagamentos/` e Gold `/fato_vendas/` contêm `part-*.parquet`: são os **registros**. Manifestos são JSON separados no bucket Results. `Glue Data Catalog` contém `location=s3://bucket/prefixo/`, tipos/colunas e não paths de todos os arquivos.

## Injetar uma falha deliberada (opcional; exige regenerar ambiente)

Antes de subir lote inicial, altere `quantidade` de um pedido no CSV para `-1`. Silver deve falhar e o gatilho condicionado não deve executar Gold. Depois corrija o arquivo **local** e recrie o ambiente de teste; como o runner protege objetos Bronze existentes de sobrescrita, não altere lote já publicado. Em ambiente real uma correção entraria como **novo lote versionado** com nova identidade, sem apagar evidências.

## Observação sobre versão

Manifestos de execução identificam entradas e saídas, mas snapshots antigos Silver/Gold foram sobrescritos. Sem Iceberg/snapshot retention não prometa consulta histórica diretamente no Athena.
