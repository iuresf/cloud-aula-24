terraform {
  required_version = ">= 1.5, < 2.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 6.0" }
  }
}
provider "aws" { region = var.region }
variable "region" {
  type    = string
  default = "us-east-1"
}
variable "project" {
  type    = string
  default = "a25-lake"
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,25}$", var.project))
    error_message = "Use 3 a 26 caracteres minusculos, numeros ou hifen."
  }
}
data "aws_caller_identity" "current" {}
locals { db = replace(var.project, "-", "_") }
resource "aws_s3_bucket" "zones" {
  for_each      = toset(["bronze", "silver", "gold", "results"])
  bucket        = "${var.project}-${each.key}-${data.aws_caller_identity.current.account_id}-${var.region}"
  force_destroy = true
  tags          = { Projeto = "Aula25", Modelo = "a25-lake" }
}
resource "aws_s3_bucket_public_access_block" "zones" {
  for_each                = aws_s3_bucket.zones
  bucket                  = each.value.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
resource "aws_s3_bucket_server_side_encryption_configuration" "zones" {
  for_each = aws_s3_bucket.zones
  bucket   = each.value.id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "AES256" }
  }
}
resource "aws_s3_bucket_versioning" "bronze" {
  bucket = aws_s3_bucket.zones["bronze"].id
  versioning_configuration { status = "Enabled" }
}
resource "aws_glue_catalog_database" "db" { name = local.db }
resource "aws_athena_workgroup" "lab" {
  name          = var.project
  force_destroy = true
  configuration {
    enforce_workgroup_configuration = true
    bytes_scanned_cutoff_per_query  = 104857600
    engine_version { selected_engine_version = "Athena engine version 3" }
    result_configuration {
      output_location = "s3://${aws_s3_bucket.zones["results"].id}/athena/"
      encryption_configuration { encryption_option = "SSE_S3" }
    }
  }
}
output "region" { value = var.region }
output "database" { value = aws_glue_catalog_database.db.name }
output "workgroup" { value = aws_athena_workgroup.lab.name }
output "buckets" { value = { for k, v in aws_s3_bucket.zones : k => v.id } }

variable "glue_role_arn" {
  type        = string
  description = "ARN exato de role existente autorizada ao Glue. Nao cria IAM."
  validation {
    condition     = can(regex("^arn:aws:iam::[0-9]{12}:role/", var.glue_role_arn))
    error_message = "Informe o ARN de uma role existente, por exemplo a LabRole, se autorizada."
  }
}
resource "aws_s3_object" "scripts" {
  for_each = toset(["silver.py", "gold.py"])
  bucket   = aws_s3_bucket.zones["results"].id
  key      = "scripts/${each.value}"
  source   = "${path.module}/jobs/${each.value}"
  etag     = filemd5("${path.module}/jobs/${each.value}")
}
resource "aws_glue_job" "etl" {
  for_each          = toset(["silver", "gold"])
  name              = "${var.project}-${each.key}"
  role_arn          = var.glue_role_arn
  glue_version      = "5.0"
  worker_type       = "G.1X"
  number_of_workers = 2
  timeout           = 10
  max_retries       = 0
  execution_property { max_concurrent_runs = 1 }
  command {
    name            = "glueetl"
    script_location = "s3://${aws_s3_object.scripts["${each.key}.py"].bucket}/${aws_s3_object.scripts["${each.key}.py"].key}"
    python_version  = "3"
  }
  default_arguments = {
    "--job-language"                     = "python"
    "--job-bookmark-option"              = "job-bookmark-disable"
    "--enable-continuous-cloudwatch-log" = "true"
    "--enable-metrics"                   = "true"
    "--BRONZE"                           = aws_s3_bucket.zones["bronze"].id
    "--SILVER"                           = aws_s3_bucket.zones["silver"].id
    "--GOLD"                             = aws_s3_bucket.zones["gold"].id
    "--DATABASE"                         = aws_glue_catalog_database.db.name

  }
}
output "jobs" { value = { for k, v in aws_glue_job.etl : k => v.name } }

resource "aws_glue_catalog_table" "pedidos" {
  name          = "pedidos"
  database_name = aws_glue_catalog_database.db.name
  table_type    = "EXTERNAL_TABLE"
  parameters    = { EXTERNAL = "TRUE", classification = "parquet" }
  storage_descriptor {
    location      = "s3://${aws_s3_bucket.zones["silver"].id}/pedidos/"
    input_format  = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
    ser_de_info {
      serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"
      parameters            = { "field.delim" = ",", "serialization.format" = "," }
    }
    columns {
      name = "pedido_id"
      type = "string"
    }
    columns {
      name = "data"
      type = "date"
    }
    columns {
      name = "valor"
      type = "decimal(12,2)"
    }
    columns {
      name = "status"
      type = "string"
    }
    columns {
      name = "canal"
      type = "string"
    }
  }
}

resource "aws_glue_catalog_table" "pagamentos" {
  name          = "pagamentos"
  database_name = aws_glue_catalog_database.db.name
  table_type    = "EXTERNAL_TABLE"
  parameters    = { EXTERNAL = "TRUE", classification = "parquet" }
  storage_descriptor {
    location      = "s3://${aws_s3_bucket.zones["silver"].id}/pagamentos/"
    input_format  = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
    ser_de_info {
      serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"
      parameters            = { "field.delim" = ",", "serialization.format" = "," }
    }
    columns {
      name = "pedido_id"
      type = "string"
    }
    columns {
      name = "resultado"
      type = "string"
    }
    columns {
      name = "atualizado_em"
      type = "timestamp"
    }
  }
}

resource "aws_glue_catalog_table" "eventos" {
  name          = "eventos"
  database_name = aws_glue_catalog_database.db.name
  table_type    = "EXTERNAL_TABLE"
  parameters    = { EXTERNAL = "TRUE", classification = "parquet" }
  storage_descriptor {
    location      = "s3://${aws_s3_bucket.zones["silver"].id}/eventos/"
    input_format  = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
    ser_de_info {
      serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"
      parameters            = { "field.delim" = ",", "serialization.format" = "," }
    }
    columns {
      name = "evento_id"
      type = "string"
    }
    columns {
      name = "sessao"
      type = "string"
    }
    columns {
      name = "evento"
      type = "string"
    }
    columns {
      name = "pedido_id"
      type = "string"
    }
    columns {
      name = "data"
      type = "date"
    }
    columns {
      name = "canal"
      type = "string"
    }
  }
}

resource "aws_glue_catalog_table" "indicadores" {
  name          = "indicadores"
  database_name = aws_glue_catalog_database.db.name
  table_type    = "EXTERNAL_TABLE"
  parameters    = { EXTERNAL = "TRUE", classification = "parquet" }
  storage_descriptor {
    location      = "s3://${aws_s3_bucket.zones["gold"].id}/indicadores/"
    input_format  = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat"
    output_format = "org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat"
    ser_de_info {
      serialization_library = "org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe"
      parameters            = { "field.delim" = ",", "serialization.format" = "," }
    }
    columns {
      name = "data"
      type = "date"
    }
    columns {
      name = "canal"
      type = "string"
    }
    columns {
      name = "receita"
      type = "decimal(14,2)"
    }
    columns {
      name = "pagos"
      type = "bigint"
    }
    columns {
      name = "cancelados"
      type = "bigint"
    }
    columns {
      name = "sessoes"
      type = "bigint"
    }
    columns {
      name = "conversao"
      type = "double"
    }
  }
}
