# Validação — Aula 25

Os arquivos Python da aula foram verificados por sintaxe e o pacote ZIP foi conferido quanto à integridade.
Não foi executado Terraform apply, Spark no Glue, Athena ou recursos AWS nesta separação.
No laboratório, rode `cd 02_data_lake && terraform init && terraform fmt -check && terraform validate && terraform plan`, revise as permissões e confirme o caminho completo antes de ensinar.
Use `python runner.py initial`, `python runner.py verify`, `python runner.py delta` e `python runner.py verify` a partir da raiz do projeto extraído.
Para o Lakehouse, confirme snapshots efetivos antes de demonstrar time travel; os exemplos contêm apenas resultados esperados.
